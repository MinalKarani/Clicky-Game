import React from "react";
import "./style.css";

function Footer() {
  return (
    <footer className="footer">
      <span>Developed By:Minal Karani</span>
    </footer>
  );
}

export default Footer;
